/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author Mauricio
 */
public class BusinessContact {
    
    String idBusinessContact, NombreContacto, EmailContacto;

    public String getIdBusinessContact() {
        return idBusinessContact;
    }

    public void setIdBusinessContact(String idBusinessContact) {
        this.idBusinessContact = idBusinessContact;
    }

    public String getNombreContacto() {
        return NombreContacto;
    }

    public void setNombreContacto(String NombreContacto) {
        this.NombreContacto = NombreContacto;
    }

    public String getEmailContacto() {
        return EmailContacto;
    }

    public void setEmailContacto(String EmailContacto) {
        this.EmailContacto = EmailContacto;
    }
    
    
}
