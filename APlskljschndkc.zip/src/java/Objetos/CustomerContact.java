/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author Mauricio
 */
public class CustomerContact {
    String idCustomerContact, NombreContacto, EmailContacto;

    public String getIdCustomerContact() {
        return idCustomerContact;
    }

    public void setIdCustomerContact(String idCustomerContact) {
        this.idCustomerContact = idCustomerContact;
    }

    public String getNombreContacto() {
        return NombreContacto;
    }

    public void setNombreContacto(String NombreContacto) {
        this.NombreContacto = NombreContacto;
    }

    public String getEmailContacto() {
        return EmailContacto;
    }

    public void setEmailContacto(String EmailContacto) {
        this.EmailContacto = EmailContacto;
    }
    
    
}
